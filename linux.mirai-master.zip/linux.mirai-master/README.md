# linux.mirai
Leaked Linux.Mirai Source Code for Research/IoC Development Purposes

Uploaded for research purposes and so we can develop IoC's and such.

See "post.txt" for the post in which it leaks, if you want to know how it is all set up and the likes.

Be careful - theres bins in there that probably connect back to heckforamz skids bullshit.



